from enum import Enum


class Errors(Enum):
    TAG_ALREADY_EXISTS = "Tag already exists"
    TAG_NOT_FOUND = "Tag not found"
   