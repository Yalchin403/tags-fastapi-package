class TagAlreadyExistsError(Exception):
    pass


class TagNotFoundError(Exception):
    pass